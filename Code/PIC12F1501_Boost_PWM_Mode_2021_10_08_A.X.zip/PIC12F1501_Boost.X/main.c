/**
 * 2021/10/07
 * This program goes along side the schematic PIC12F1501 boost converter
 * This uses PWM mode and not PFM mode. This powers 4 LEDs in series
 * at various currents selectable by CurrentSetpoint.
 * Set point is in mV but the max practical seems to be around 160mV
 * and is probably lower. When set at 160mV, the sense resistor is around
 * 120mV and wont go much higher. Any more would probably be a waste. 

*/
#include "mcc_generated_files/mcc.h"

/*
                         Main application
 */

unsigned int ADC_Result;
unsigned int increment_Value;
int error;
unsigned int adc_return;
unsigned int VDD = 0;
unsigned long k;
unsigned int k2;
unsigned Isense_Measured;


/*
Current set point. 1000 = 100mV, 1500=150mV, 80 = 80mV
There is some range here and its not precise but its good enough.
 * Practical set point max seems to be around 200
*/

#define CurrentSetpoint 5


#define _XTAL_FREQ 16000000
//NCO NOT USED
#define NCO_MIN 16384
#define	NCO_MAX	29214//app. 400kHz,
//PWM mode runs at 200Khz. If the frequency is changed then these values
//must be changed as well.
#define PWM_min 39 //50%
#define PWM_max 73 //93%


//NOT USED, Old function
void set_NCO()
{
		if(increment_Value < NCO_MIN) increment_Value = NCO_MIN;
		if(increment_Value > NCO_MAX) increment_Value = NCO_MAX;
		NCO1INCH = increment_Value >> 8;
		NCO1INCL = increment_Value & 0xFF;
}

void set_PWM()
{

     // Writing to 8 MSBs of PWM duty cycle in PWMDCH register
     PWM1DCH = (increment_Value & 0x03FC)>>2;
     
     // Writing to 2 LSBs of PWM duty cycle in PWMDCL register
     PWM1DCL = (increment_Value & 0x0003)<<6;
 }



void main(void)
{
    // initialize the device
    SYSTEM_Initialize();

     if (FVRCONbits.FVRRDY==1) 
    //this just checks to make sure that the FVR is running. FVR = fixed voltage reference
    //assumed to be 2.048VDC. Can also measure channel 2 which is 1.024VDC
    {
    ADC_Result=ADC_GetConversion(channel_FVR)   ;
    //this code takes a reading of the FVR
    } 
    //assume Vref is 2.048V. Ideally I should output to a pin and measure.
    //Find VDD, the voltage that is powering the microcontroller. We need
    //this for the next formula to convert an unknown voltage from an analog pin
    //to a real life voltage
    k=(2048L*1024L);
    VDD=(k/ADC_Result);
     //3.3V=3300
    ADC_Result=0;   //clear it
    
    //Lets do some pre math.
    //Vunknown = ADC Code * (VDD/2^n), in this case 2^n = 4095 due to the 12 bit ADC
    //In other cases it will be 10 bits or 1023.
    //I divided 4096 to make the numbers more managable. 
    k2=(VDD)/102;
 
increment_Value=0;

    while (1)
    {

        ADC_Result=ADC_GetConversion (Isense);
        Isense_Measured=((ADC_Result)*k2)/10;
        //result is now in mV. 96 = 96mV 
        //error = CurrentSetpoint-Isense_Measured;
        
        //Just check boundaries so we dont go over.
        if(increment_Value < PWM_min) increment_Value = PWM_min;
        if(increment_Value > PWM_max) increment_Value = PWM_max;   
        
        if(Isense_Measured<=CurrentSetpoint)increment_Value++;
        if(Isense_Measured>=CurrentSetpoint)increment_Value--;        
        
        //increment_Value=((increment_Value/1000)+(error));

       // __delay_ms(1000);
        
		set_PWM();
        
        
//		if (error>10 || error <-10)
//        {
//
//		}
        	

        
                                    
        
    }
}



//int main()
//{
//unsigned int increment_Value;
//unsigned char NCO1INCH;
//unsigned char NCO1INCL;
//
//increment_Value=4095;
//
//NCO1INCH = increment_Value >> 8;
//NCO1INCL = increment_Value & 0xFF;
//
//  printf("%08i",NCO1INCH);
//  printf("%08i",NCO1INCL);
//}

